#!/usr/bin/env python3
"""Read the pinned, offline paired RR standalone package; never execute a model."""
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import sys
import tarfile

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "reproduce"))
from native_directory import NativeDirectory, read_regular_bytes

INPUTS = ("bet.frq", "bet.ini", "bet.tag", "bet.age_length", "bet.reg_scaling", "mfcl.cfg")
MANIFEST_SHA256 = "56d944907910c4e7f57cdeebaceab38966067ecee2cc33b501c1b88010e2f233"
MFCL_SHA256 = "f5bc1e232a86e51f920bce7271d8e0930d0b160e4d18dc46de44078f0fa24cd0"
MODELS = ('ensemble-005', 'ensemble-006', 'ensemble-007', 'ensemble-008', 'ensemble-014', 'ensemble-027', 'ensemble-029', 'ensemble-032', 'ensemble-033', 'ensemble-034', 'ensemble-035', 'ensemble-040', 'ensemble-042', 'ensemble-043', 'ensemble-044', 'ensemble-045', 'ensemble-046', 'ensemble-049', 'ensemble-052', 'ensemble-062', 'ensemble-063', 'ensemble-065', 'ensemble-071', 'ensemble-074', 'ensemble-078', 'ensemble-086', 'ensemble-089', 'ensemble-092', 'ensemble-094', 'ensemble-095', 'rrtest-005-rr1', 'rrtest-006-rr1', 'rrtest-007-rr1', 'rrtest-008-rr1', 'rrtest-014-rr1', 'rrtest-027-rr1', 'rrtest-029-rr1', 'rrtest-032-rr1', 'rrtest-033-rr1', 'rrtest-034-rr1', 'rrtest-035-rr1', 'rrtest-040-rr1', 'rrtest-042-rr1', 'rrtest-043-rr1', 'rrtest-044-rr1', 'rrtest-045-rr1', 'rrtest-046-rr1', 'rrtest-049-rr1', 'rrtest-052-rr1', 'rrtest-062-rr1', 'rrtest-063-rr1', 'rrtest-065-rr1', 'rrtest-071-rr1', 'rrtest-074-rr1', 'rrtest-078-rr1', 'rrtest-086-rr1', 'rrtest-089-rr1', 'rrtest-092-rr1', 'rrtest-094-rr1', 'rrtest-095-rr1')
EXCLUDED = ("rrtest-001-rr1", "rrtest-022-rr1", "rrtest-025-rr1", "rrtest-080-rr1")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def checked(data, record):
    require(isinstance(data, bytes) and len(data) == record["bytes"]
            and hashlib.sha256(data).hexdigest() == record["sha256"], "Saved bytes differ")
    return data


def payload_bytes(data, records):
    """Decode only bounded regular CAS members; never extract archive paths."""
    expected = {row["path"]: row for row in records}
    require(len(expected) == len(records), "Duplicate payload manifest path")
    require(len(expected) <= 500, "Too many payload members")
    require(sum(row["bytes"] for row in records) <= 250_000_000, "Payload exceeds bound")
    for name, row in expected.items():
        require(re.fullmatch(r"objects/[0-9a-f]{64}", name) is not None
                and name == "objects/" + row["sha256"] and row["mode"] == 0o644
                and isinstance(row["bytes"], int) and 0 <= row["bytes"] <= 4_000_000,
                "Invalid payload manifest member")
    result = {}
    with tarfile.open(fileobj=io.BytesIO(data), mode="r:gz") as archive:
        for member in archive:
            require(member.name in expected and member.name not in result,
                    "Unexpected or duplicate payload member")
            row = expected[member.name]
            require(member.isfile() and not member.pax_headers and member.mode == row["mode"]
                    and member.size == row["bytes"], "Unsupported payload type, size or mode")
            stream = archive.extractfile(member)
            require(stream is not None, "Unreadable regular payload member")
            result[member.name] = checked(stream.read(row["bytes"] + 1), row)
    require(result.keys() == expected.keys(), "Missing payload members")
    return result


class Source:
    def __init__(self, root=ROOT):
        self.root = Path(root).absolute()
        manifest = read_regular_bytes(self.root / "manifest.json")
        require(hashlib.sha256(manifest).hexdigest() == MANIFEST_SHA256, "Manifest checksum mismatch")
        self.manifest = json.loads(manifest)
        require(self.manifest["schema_version"] == 1, "Unknown standalone schema")
        rows = self.manifest["models"]
        self.models = {row["model"]: row for row in rows}
        require(len(self.models) == len(rows) == 60 and tuple(sorted(self.models)) == MODELS,
                "Expected exactly 30 completed RR0/RR1 pairs, 60 saved models")
        require(tuple(self.manifest["excluded_failed_models"]) == EXCLUDED,
                "Failed model membership differs")
        require(sum(row["arm"]=="RR0" for row in rows)==30 and sum(row["arm"]=="RR1" for row in rows)==30
                and all(row["paired_model"] in self.models and self.models[row["paired_model"]]["paired_model"]==row["model"]
                        and self.models[row["paired_model"]]["anchor"]==row["anchor"] for row in rows),
                "Paired arm membership differs")
        recipe = self.manifest["payload"]
        require(recipe["path"] == "native.tar.gz", "Unexpected payload path")
        data = checked(read_regular_bytes(self.root / recipe["path"]), recipe)
        self.payload = payload_bytes(data, recipe["objects"])
        self.members = {row["path"]: row for row in recipe["objects"]}
        engine = self.manifest["engine"]
        require(engine["path"] == "mfclo64" and engine["sha256"] == MFCL_SHA256
                and engine["bytes"] == 34549392 and engine["mode"] == 0o755,
                "Unexpected engine binding")
        self.engine = checked(read_regular_bytes(self.root / "mfclo64"), engine)
        for row in self.manifest["controllers"]:
            require(row["path"] in ("rr-test/evaluate-final.py", "reproduce/native_directory.py"),
                    "Unexpected original controller")
            checked(read_regular_bytes(self.root / row["path"]), row)
        require({row["path"] for row in self.manifest["controllers"]}
                == {"rr-test/evaluate-final.py", "reproduce/native_directory.py"},
                "Missing original controller")
        require(self.manifest["variants"] == [], "Unexpected controller variant")
        require(self.manifest["validation_contract"]["function_evaluation_limit"] == 1,
                "Standalone must use the original function-evaluation ceiling 1")

    def model(self, name):
        require(name in self.models, "No saved final PAR for this selector; failed fits cannot regenerate outputs")
        return self.models[name]

    def read(self, record):
        require(record["storage"] == "archive" and record["member"] in self.members,
                "Unknown saved-file storage or member")
        row = self.members[record["member"]]
        require(record["sha256"] == row["sha256"] and record["bytes"] == row["bytes"]
                and isinstance(record["mode"], int) and 0 <= record["mode"] <= 0o777,
                "Saved model binding differs")
        return checked(self.payload[record["member"]], record)

    def input_hashes(self, name):
        row = self.model(name)
        expected = row["native_input_sha256"]
        require(set(expected) == set(INPUTS), "Exactly six native input hashes required")
        hashes = {file: hashlib.sha256(self.read(row["files"][file])).hexdigest() for file in INPUTS}
        require(hashes == expected, "Saved native inputs differ from original hashes")
        lines = self.read(row["input_manifest"]).decode().splitlines()
        original = {}
        for line in lines:
            parts = line.split(None, 1)
            require(len(parts) == 2 and re.fullmatch(r"[0-9a-f]{64}", parts[0]) is not None
                    and parts[1] not in original, "Invalid original input manifest")
            original[parts[1]] = parts[0]
        require(all(original.get(file) == hashes[file] for file in INPUTS),
                "Original input manifest binding differs")
        for file in ("model-inputs/S0.90-F2.conf", "selectivity-models/F2.csv"):
            require(hashlib.sha256(self.read(row["refit_files"][file])).hexdigest() == original.get(file),
                    "Original nested refit input binding differs")
        return expected

    def native_files(self, name):
        row = self.model(name)
        self.input_hashes(name)
        files = {file: (self.read(row["files"][file]), row["files"][file]["mode"])
                 for file in (*INPUTS, "doitall.sh")}
        files["final.par"] = (self.read(row["final_par"]), row["final_par"]["mode"])
        files["mfclo64"] = (self.engine, 0o755)
        return files

    def verify(self):
        for name in self.models:
            row = self.model(name)
            self.native_files(name)
            self.read(row["reference_rep"])
        return len(self.models)

    def restore(self, name, output):
        """Create one fresh directory outside this source tree, with exact source modes."""
        output = Path(os.path.abspath(output))
        require(output.name not in ("", ".", "..") and output != self.root
                and self.root not in output.parents and output not in self.root.parents,
                "Working directory must be outside the standalone source tree")
        row = self.model(name)
        files = self.native_files(name)
        with NativeDirectory(output.parent) as parent:
            require(not parent.exists(output.name), "Existing working directory refused")
            with parent.create_child(output.name) as directory:
                directory.stage_files(files, name)
                for filename, record in row["refit_files"].items():
                    parts = filename.split("/")
                    require(len(parts) == 2 and parts[0] in ("model-inputs", "selectivity-models")
                            and parts[1] in ("S0.90-F2.conf", "F2.csv"), "Unexpected refit path")
                    with directory.create_child(parts[0]) as child:
                        child.write_new(parts[1], self.read(record), record["mode"])
                directory.write_new("original-INPUTS.sha256", self.read(row["input_manifest"]), 0o644)
        return output
