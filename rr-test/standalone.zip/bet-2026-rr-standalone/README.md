# RR standalone saved-PAR package

This ZIP contains both arms of the 30 completed comparisons: 30 RR0 anchors and 30 RR1 fits, each with its saved last `final.par`, six exact inputs, original `doitall.sh`, nested refit files and compact central REP references. One static MFCL engine serves all 60 cases. Failed RR1 fits 001, 022, 025 and 080 have no saved PAR and remain excluded; the original repository archive retains their anchors.

Choose a case and a new directory outside this package. Its parent must exist. Evaluation requires Linux x86-64, Python 3.8 or newer and `/proc/self/fd`; it needs no network, R, Docker or job history.

```sh
unzip standalone.zip
cd bet-2026-rr-standalone
./run-final --list
./run-final --verify
./run-final rrtest-005-rr1 /tmp/bet-rrtest-005-evaluation
./run-final ensemble-005 /tmp/bet-ensemble-005-evaluation
```

The default uses the unchanged original saved-PAR controller, with function-evaluation **ceiling 1** (`1 1 1`). After central-output checks, the wrapper requires actual native records of **1,997 variables, iteration 0, function evaluation 0**; absent or nonzero counters fail. Ceiling 1 and reported counter 0 are different values. No fitting iterations are accepted by this command. Earlier literal-zero (`1 1 0`) tests omitted `Adult biomass in absence of fishing` in ensemble-005, ensemble-063 and rrtest-035-rr1; that incomplete mode is excluded from this package. Those runs also emitted no native iteration/function-evaluation counter records, so they do not establish reported counter zero.

Outputs go into the fresh directory: `evaluated.par`, `plot-evaluated.par.rep`, `mfcl-evaluation.log`, the original `evaluation-check.json` and wrapper `native-counter-check.json`, plus other files actually produced by MFCL. Checks require the saved objective within `1e-6`, exactly 1,997 parameters, and every original central REP value within `1e-10 × max(1, |saved value|)`. Saved/staged PAR and six inputs must remain unchanged. Existing output directories are refused. Paired tables and figures retain their repository regeneration instructions. Fresh all-60 native proof is recorded separately by GitHub CI.

For an optional full refit in a separate working copy:

```sh
./run-final --prepare-only rrtest-005-rr1 /tmp/bet-rrtest-005-refit
cd /tmp/bet-rrtest-005-refit
MODEL_ID=S0.90-F2 PROGRAM_PATH=./mfclo64 BET_PHASE10_11_CONVERGENCE=-4 sh ./doitall.sh
```

Preparation executes no model. The final command starts the original fitting sequence from INI `-makepar` values, requires POSIX `sh`, `awk`, `cmp` and `cp`, and writes fresh phase files including `11.par`. Keep `final.par` as the saved reference. A full refit is a separate scientific run and can take substantially longer; byte-identical refits are not promised.

`manifest.json` binds every case to original paths/members, bytes, modes, input hashes and whole-REP source hashes. `native.tar.gz` stores identical bytes once under SHA256 names. Compact REP sections preserve original bytes; whole REP files are not duplicated. `sha256sum -c CONTENTS.sha256` checks the package, and `./run-final --verify` checks all saved bindings without executing MFCL.

Sources are [Ensemble 22aac848](https://github.com/PacificCommunity/ofp-sam-bet-2026-ensemble/tree/22aac8488312abecf8249f9f1e3f951215ff77a7) and the [Jitter executable at bb3f4016](https://github.com/PacificCommunity/ofp-sam-bet-2026-jitter/blob/bb3f4016b2d145f42c7a76072ed2b10b49aff71f/data/diagnostic/mfcl/mfclo64), SHA256 `f5bc1e232a86e51f920bce7271d8e0930d0b160e4d18dc46de44078f0fa24cd0`. The evaluation controller and directory guard are byte-exact original files. Historical external anchor executable identity remains **UNKNOWN**; the separate prepared-file executable hash in original `INPUTS.sha256` does not establish actual historical execution identity.

`F2.csv` is copied from public source. Each case `.conf` was assembled as text and accepted only after matching its original public input-ledger SHA256. No inputs, PARs, fit settings, central references or model algorithms were changed. Archive construction and offline fixture checks execute neither R nor MFCL.
