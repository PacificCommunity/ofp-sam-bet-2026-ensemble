# BET 2026 paired RR fits

30 completed pairs: RR0 includes tag reporting rates; RR1 excludes them.
Four RR1 attempts failed: 001, 022, 025 and 080. They have no saved final PAR.

```sh
make unpack
make list
make verify
make rerun CASE=rrtest-005-rr1 OUT=/tmp/bet-rr1-005
make rerun CASE=ensemble-005 OUT=/tmp/bet-rr0-005
```

R calls the included MFCL executable directly. Native runs need Linux x86-64,
R, Make, tar with XZ support and SHA-256 tools; no R packages or downloads.
Use a new output folder each time.

After `make unpack`, each `models/<case>/` contains the saved `final.par`,
`bet.frq`, `bet.ini`, `bet.tag`, `bet.age_length`, `bet.reg_scaling`, `mfcl.cfg`,
original `doitall.sh`, its two configuration files, the central reference REP
and the original input ledger. The shared executable is `mfclo64`.

`make rerun` copies those files into OUT and writes normal MFCL outputs,
including `evaluated.par` and `plot-evaluated.par.rep`. R checks the objective,
native counters and ten central REP sections, then writes `evaluation-check.csv`,
annual `central-results.csv` and recent `management-quantities.csv`.

The original control sets an evaluation ceiling of 1; the required native
iteration and function counter are 0. A literal ceiling of 0 omits required
biomass output. The saved PAR and inputs remain unchanged.

To inspect a plain working copy or start the original full fit:

```sh
make prepare CASE=rrtest-005-rr1 OUT=/tmp/bet-rr1-inputs
make refit CASE=rrtest-005-rr1 OUT=/tmp/bet-rr1-refit
```

Refit runs the original `doitall.sh` and produces `11.par`. It is a new fit;
the quick saved-PAR check does not establish full-refit or whole-output equality.
These are historical pre-fix results. The historical RR0 executable identity
remains unknown.

[Results and figures](https://github.com/PacificCommunity/ofp-sam-bet-2026-ensemble/blob/main/rr-test/results.md)
· [Reference document](https://meetings.wcpfc.int/node/32932)

`FILES.csv` records the delivered file checksums. `source-manifest.json` retains
the original package provenance; its SHA-named archive paths describe the source
package, not this ordinary-directory archive. Figure 2B–C also uses the
repository's planned-100 and retained-80 tables.
