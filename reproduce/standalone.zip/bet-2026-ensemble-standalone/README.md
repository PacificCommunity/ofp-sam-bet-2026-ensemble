# Preserved BET ensemble native files

This offline package contains the 80 original retained ensemble fits, with exact native inputs, saved final PARs, original `doitall.sh` controllers, and their configuration/selectivity files. The files have their original bytes and permission modes. `reference.rep` preserves the original version header and ten exact central REP sections. `models.csv` retains the complete source REP checksum separately; `source-manifest.json` records source commits and per-file bindings.

Use base R, Make, a system tar that reads XZ, and `sha256sum` or `shasum`. Native execution requires Linux x86-64. There are no downloads, R package installations, Python runtime, Docker or job-history dependencies.

```sh
make list
make unpack
make verify
make prepare CASE=ensemble-001 OUT=/tmp/bet-001-inputs
make rerun CASE=ensemble-001 OUT=/tmp/bet-001-evaluated
```

Choose a fresh absolute OUT directory outside this package. For repository commands, outputs inside the checkout must be beneath `outputs/`; OUT's parent must already exist. `prepare` copies native files and the checked engine without executing it. `rerun` prepares its own fresh working copy and evaluates the saved PAR with the preserved ceiling-one controls. It requires actual native records matching the saved parameter count, iteration 0 and function evaluation 0; objective agreement within 1e-6; and central REP agreement within 1e-10 relative tolerance. Native exit 0 or 3 is accepted only when all checks pass. Raw outputs and the complete stdout/stderr log remain available.

The output includes `evaluation-check.csv`, annual `central-results.csv`, and one-row `management-quantities.csv`. Annual biomass sums the five regions within each quarter, then averages four quarters; annual depletion uses the matching-year unfished biomass. Recent SB/SB0 divides mean SB in 2021–2024 by mean SB0 in 2014–2023; SB/SBMSY uses mean SB in 2021–2024 and the native adult biomass at MSY. Recent F/FMSY is the reciprocal of the native F multiplier at MSY.

A full refit is a separate explicit action:

```sh
make refit CASE=ensemble-001 OUT=/tmp/bet-001-refit
```

It runs the case's unchanged original `doitall.sh` from its ordinary input initialization, using `PROGRAM_PATH=./mfclo64`, `MODEL_ID=S0.90-F2` and phase 10/11 criterion `-4`. Its fitted result is `11.par`; the preserved `final.par` remains unchanged. This may require substantial time. No full refit was run to build this package. Saved-PAR evaluation checks compatibility of the checked static engine; source records retain the separate historical engine identities and unresolved provenance.

`runtime-INPUTS.sha256` is a generated runtime binding for exactly the six native input files. Historical input manifests exist for 34 cases. Their original source bindings and text are preserved in `source-manifest.json`; the other 46 are explicitly recorded without a historical manifest.

Direct equivalents are `Rscript run-final.R ACTION [CASE] [OUT]` and `./run-final ACTION [CASE] [OUT]`, where ACTION is `list`, `unpack`, `verify`, `prepare`, `rerun` or `refit`.
